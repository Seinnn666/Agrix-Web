AgriX Web Unit Test Evidence
Test Cycle No.: 1
Date Tested: 2026-11-01 (Asia/Manila)
Type of System: Web application
Environment: Local AgriX web instance at localhost:8082; client and administrator roles

Scope
The recorded web modules are Admin Login, Admin Console, Admin Profile, User Management, Admin Notifications, Admin Dashboard, Client Landing Page, Client Login, Forgot Password, Client Dashboard, Client Notifications, Client Profile, Device Sensors, Reading Timeline, Graph History, Snapshot Gallery, Alert History, and Open Monitoring.

Saved screenshot evidence
landing.jpg — Client Landing Page
client-dashboard.jpg — Client Dashboard
client-notifications.jpg — Client Notifications
client-profile.jpg — Client Profile
client-open-monitoring.jpg — Client Open Monitoring

Observed results
Client login succeeded and protected client pages were reachable. Client notifications displayed an empty state. Device sensor status was offline and there were no readings, snapshots, or alerts in the observed account. Reading Timeline and Graph History displayed no reading data; Graph History also displayed a failed-to-load-readings message. Open Monitoring showed no sensor data and reported the API as Online at the time observed.
Administrator login succeeded. Admin Dashboard/Console displayed user summary counts, with a transient initial zero/no-users view before values appeared. User Management and Admin Profile were reachable. Admin Notifications displayed an empty state. No user records were changed.

Evidence limitations
The browser session expired before remaining screens could be saved as local screenshot files. Those views were observed during the session, but this bundle does not contain image evidence for them. No system behavior or successful data retrieval is inferred from empty states. Admin Console and Admin Dashboard share the same observed AdminDashboard route in this build.

Source format
The attached Unit Test Document.docx specifies: Module Name, Test Cycle No., Component Name, Date Tested, Type of System, Pre-conditions, Action Description, Verification Steps, scenario table (Data/Input, Expected Results, Actual Results, Remarks), screenshot, and Prepared/Performed By. This evidence note summarizes the observed run; it is not a completed copy of that form.
